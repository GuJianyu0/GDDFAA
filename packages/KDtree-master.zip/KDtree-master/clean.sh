#!/bin/bash
rm -rdf ./build > /dev/null 2>&1
rm -rdf ./*~ > /dev/null 2>&1
