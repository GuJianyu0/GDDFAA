#!/bin/bash
./build/test*
