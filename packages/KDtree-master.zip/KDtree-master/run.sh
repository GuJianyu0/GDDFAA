#!/bin/bash
./build/main
